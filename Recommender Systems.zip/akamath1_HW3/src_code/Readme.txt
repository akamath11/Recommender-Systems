Please enter the K value required after running the code:

K refers to number of features in Matrix factorization
K refers to number of neighbors for Neighborhood methods