import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix

import time
start_time = time.time()


K=10

K=input('Enter K value')

train=pd.read_csv('train.csv',header=None)
train=train.drop([3],axis=1)

f = open('dev.queries','r')
dev=f.read()
dev=dev.split('\n')
      

users=train[1]
items=train[0]
num_users=max(users)+1
num_items=max(items)+1

values=train[2]


imputed_values=values-3 #Imputation

M=csr_matrix((imputed_values,(items,users)),shape=(num_items,num_users))


query_users=[]

I=[]
J=[]
val=[]
user_ids=[]
index=[]
for i in range(len(dev)):
    user_id=int(dev[i].split(' ')[0])
    col_val=dev[i].split(' ')[1:]
    J.extend(np.array([col.split(':')[0] for col in col_val]).astype('float'))
    val.extend(np.array([col.split(':')[1] for col in col_val]).astype('float'))
    I.extend(np.array([user_id for col in col_val]).astype('float'))


#Only contains users for which data is given, all others are 0
dev_mat=csr_matrix((np.array(val)-3,(J,I)),shape=(num_items,num_users))

similarity=dev_mat*np.transpose(M)

query=pd.read_csv('dev.csv',header=None)

global_score=float(train[2].sum())/len(train)

#For the rows/user_ids in the query find the similarity row
fout=open('check_this.txt','w')

for i in range(len(query)):
    print(i)
    user=query.loc[i][1]
    movie=query.loc[i][0]
    

    sim=np.squeeze(np.asarray(similarity[movie].todense()))
    
        
    KNN=list(np.argsort(sim)[::-1][:K+1])
    if(user in KNN):
        KNN.remove(user)
    else:
        KNN.remove(KNN[-1])
        
    K_Scores=sim[KNN]
    
    #Find scores for all items averaging over KNN
    score=0
    k=0
    for j in KNN:
        score+=M[j,user]*K_Scores[k]
        k=k+1
    if(sum(K_Scores)!=0):
        score=np.float(score)/sum(K_Scores)
    
            
        
    
    score=score+3    
    fout.write(str(score))
    fout.write('\n')
    

print("--- %s seconds ---" % (time.time() - start_time))          
    
 
    
    













