import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix

import time
start_time = time.time()


K=10
K=input('Enter K value')

train=pd.read_csv('train.csv',header=None)
train=train.drop([3],axis=1)

f = open('dev.queries','r')
dev=f.read()
dev=dev.split('\n')
      

users=train[1]
items=train[0]
num_users=max(users)+1
num_items=max(items)+1

values=train[2]


imputed_values=values-3 #Imputation

M=csr_matrix((imputed_values,(users,items)),shape=(num_users,num_items))


query_users=[]

I=[]
J=[]
val=[]
user_ids=[]
index=[]
for i in range(len(dev)):
    user_id=int(dev[i].split(' ')[0])
    col_val=dev[i].split(' ')[1:]
    J.extend(np.array([col.split(':')[0] for col in col_val]).astype('float'))
    val.extend(np.array([col.split(':')[1] for col in col_val]).astype('float'))
    I.extend(np.array([user_id for col in col_val]).astype('float'))


#Only contains users for which data is given, all others are 0
dev_mat=csr_matrix((np.array(val)-3,(I,J)),shape=(num_users,num_items))

similarity=dev_mat*np.transpose(M)

train_norm=np.ones(num_users)
# Find normalization constants and append to array
for i in range(num_users):
    user_vector=np.squeeze(np.asarray(M[i].todense()))
    norm=np.float(np.sqrt((user_vector**2).sum()))
    if(norm==0):
        continue
    train_norm[i]=(norm)
    
values=np.ones(num_users)
keys=range(num_users)
dev_dict_norm=dict(zip(keys,values))

for i in range(num_users):
    user_vector=np.squeeze(np.asarray(dev_mat[i].todense()))
    norm=np.float(np.sqrt((user_vector**2).sum()))
    if(norm==0):
       continue
    dev_dict_norm[i]=norm
    
#Standardize all rows
train_Means=[]
train_Var=[]
for i in range(num_users):
    user_vector=np.squeeze(np.asarray(M[i].todense()))
    Mean=np.sum(user_vector)/(user_vector!=0).sum()
    train_Means.append(Mean)
    Variance=np.var(user_vector)
    train_Var.append(Variance)

keys=range(num_users)
values=train_Means
train_Means_dict=dict(zip(keys,values))   

values=train_Var
train_Var_dict=dict(zip(keys,values)) 



query=pd.read_csv('dev.csv',header=None)

global_score=float(train[2].sum())/len(train)

#For the rows/user_ids in the query find the similarity row
fout=open('check_this.txt','w')

for i in range(len(query)):
    print(i)
    user=query.loc[i][1]
    movie=query.loc[i][0]
    

    sim=np.squeeze(np.asarray(similarity[user].todense()))
    
    # Converting Dot product to cosine scores
    sim=sim/dev_dict_norm[user]
    sim=sim/train_norm
    
    # If the user has no ratings
    
    if(not sim.any()):
        score=M[:,movie].mean()

        
    KNN=list(np.argsort(sim)[::-1][:K+1])
    if(user in KNN):
        KNN.remove(user)
    else:
        KNN.remove(KNN[-1])
        
    #K_Scores=sim[KNN]
    
    #Find scores for all items averaging over KNN
    K_Scores=sim[KNN]
    
    #Find scores for all items averaging over KNN
    score=0
    k=0
    for j in KNN:
        score+=K_Scores[k]*(M[j,movie]-M[j,:].mean())/np.var(M[j,:].todense())
        k=k+1
    if(K_Scores.sum()!=0):
        score=np.float(score)/K_Scores.sum()
    
    score=M[user,:].mean()+np.var(M[user,:].todense())*(score)
    
            
        
    
    score=score+3    
    fout.write(str(score))
    fout.write('\n')
 
    
print("--- %s seconds ---" % (time.time() - start_time))    













